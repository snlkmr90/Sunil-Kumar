<?php 
$this->load->view('admin/layout/header');
$this->load->view('admin/layout/sidebar');
echo $contents;
$this->load->view('admin/layout/footer');

 ?>