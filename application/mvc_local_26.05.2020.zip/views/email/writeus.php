<table>
    <tbody>
        <tr>
            <td>subject</td>
            <td><?= $writeus_subject; ?></td>
        </tr>
        <tr>
            <td>Name</td>
            <td><?= $writeus_name; ?></td>
        </tr>
        <tr>
            <td>Email</td>
            <td><?= $writeus_email; ?></td>
        </tr>
        <tr>
            <td>Message</td>
            <td><?= $writeus_message; ?></td>
        </tr>
    </tbody>
</table>