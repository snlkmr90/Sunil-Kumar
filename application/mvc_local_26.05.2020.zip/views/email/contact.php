<table>
    <tbody>
        <tr>
            <td>subject</td>
            <td><?= $contact_subject; ?></td>
        </tr>
        <tr>
            <td>Name</td>
            <td><?= $contact_name; ?></td>
        </tr>
        <tr>
            <td>Email</td>
            <td><?= $contact_email; ?></td>
        </tr>
        <tr>
            <td>Phone</td>
            <td><?= $contact_phone; ?></td>
        </tr>
        <tr>
            <td>Message</td>
            <td><?= $contact_message; ?></td>
        </tr>
    </tbody>
</table>